# Kick-off prompt

Paste this to the Claude Code agent, in the repository devcontainer, on a fresh
branch from `main`.

---

You're bringing the Calcium repository into line with the Calcium design language.
The design language is now the source of truth for **appearance, interaction and
navigation**, and it overrides what the repository does today in those areas.

**What's in the kit, and how much weight each part carries:**

- `design/calcium-design-language-revised.html` — **the picture.** This is what
  Calcium should look and behave like. When in doubt, match this.
- `design/calcium-registry.json` — the same thing as data, with stable rule IDs.
- `01-RECONCILIATION.md` — the known places the repository and the design language
  disagree, already checked against the code. Start here.
- `tasks/` and `reference/` — **suggestions, not a checklist.** They're one way to
  split the work and background on why things are the way they are. Use what helps,
  ignore what doesn't, and re-order or merge tasks if that makes more sense.

**Use your judgement.** Plan the work yourself from the reconciliation and the HTML.
Only bring in what's actually needed — don't recreate tooling the repository
already has (`make enforce`, `make golden`, `make refdiff`, the keymap generator), and
don't build machinery for its own sake. A smaller change that matches the design
language is better than a larger one that matches the kit.

**The repository's rules still apply** (read `CLAUDE.md`):
- Run everything in the devcontainer; `node --version` should be v22.
- If a spec disagrees with the design language, change the spec first, then the code.
- Keep `make enforce` and `make test` green.
- One coherent change per MR. Open it green and stop.

**Stop and ask** if the design language looks wrong or contradicts itself, or if a
change would break a public export. Otherwise, make the call.

Start by reading `01-RECONCILIATION.md` and the HTML, then tell me your plan before
writing code.
