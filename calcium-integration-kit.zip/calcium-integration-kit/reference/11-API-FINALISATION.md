> **Reference input** for the integration tasks. Where this file and the repository differ,
> the task that cites it decides. It is not an instruction on its own.


> **`status: approved-plan`** — phase 1. **The registry is the only normative source.**

# 11 · Finalising the executable API

**The published `Box` type cannot express the engine's own algorithm.** Four gaps, all
found by a review reading the type against the spec.

## 1 · `Grow` has no weight

**`LAYOUT_ENGINE.md` requires weighted growth. `Grow(min, max)` cannot say it.**

```
Grow(min = 0, max = \u221e, weight = 1)
```

**Distribution uses the weights**; equal weights reduce to the current behaviour, so **no
existing frame moves.** That is the check: adding this must move ZERO goldens.

## 2 · `layout()` receives no available height

**Vertical grow and shrink are specified and uncallable.**

```
layout(box, availableWidth, availableHeight = null)
```

**`null` means "solve to natural height"**, which is what every current caller wants. **A
column with `Grow` height and no available height is a construction error, not a silent zero.**

## 3 · The paint interface lacks a natural width

**Leaves are asked for a natural width and the published interface has no field for it.**

```
interface Paint {
  naturalWidth: number
  measure(width): number           // MUST answer without rendering
  render(width, height): Row[]
}
```

**`measure` answering without rendering is the whole reason the producer declares a cell
rectangle** — it is why the image sizing contract works.

## 4 · The cache key is incomplete

**Keyed on identity and width. Results also depend on height, representation and
capability.**

```
key = (boxIdentity, width, height, chosenRepresentation, capabilityVector)
```

**Measured previously**: 421 absent misses, zero width misses — which says the width key was
never the problem and the missing dimensions were never exercised. **A wrong cache hit here
is silent**, which puts it in the same class as the coordinate systems.

## Gate

**All four land together, and the goldens must not move.** A moved frame means one of them
changed behaviour rather than expressing it.
