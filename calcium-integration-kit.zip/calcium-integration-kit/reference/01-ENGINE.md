> **Reference input** for the integration tasks. Where this file and the repository differ,
> the task that cites it decides. It is not an instruction on its own.


> **`status: approved-plan`** — the engine, pending the API finalisation in 11.
> **The registry is the only normative source.** Where this file and
> `source/calcium-registry.json` disagree, **the registry wins.**

# 01 · The layout engine

**Build this first.** It exists twice already — Python and JavaScript — and the two agree on
the first distribution test. You are porting a verified design, not discovering one.

**Read**: `spec/LAYOUT_ENGINE.md` (22 sections, the full contract) and the `<script>` in
`source/calcium-interaction-prototype.html`, which is a working implementation.

## The Box

```
width, height     Fixed(n) | Fit(min,max) | Grow(min,max) | Percent(p)
direction         row | column
pad, gap          padding and childGap. THERE IS NO MARGIN
align_x, align_y  l | c | r  ·  t | c | b  ·  stretch
min_w             a FLOOR for content, a THRESHOLD for decoration
drop              shed priority. 0 NEVER sheds
reps              [(min_width, Box)] — a different SHAPE at a smaller size
trunc             (n) -> string — the KIND shortens itself to its solved width
decor, fill       decoration: it never widens its container
el, kind          a focusable element; its SOLVED RECT is its hit rect
scrollable, layer for scroll ownership
dismiss           for click-outside-to-close
```

## The five passes

```
1  fit-width
2  grow / shrink width
3  RE-FIT HEIGHT          <- width feeds height
4  grow / shrink height
5  position
```

**Width feeds height; height NEVER feeds back.** That is what makes one re-fit a fixed point
rather than an iteration, and it is the property to preserve above all others.

**Children declare, parents derive.** No child reads its parent.

## The seven bugs this design found by being built

**Each is a named regression test. Do not rediscover them.**

```
1  naturalW ignored a declared Fixed width — a row of fixed columns collapsed
   to its text
2  Fixed was not a floor in distribution
3  a non-GROW child took its natural rather than its declared width beside a
   GROW sibling
4  representations were chosen against the ROW'S width, not the CHILD'S share
5  nested vertical GROW did not propagate — children were solved before the
   parent knew its height
6  dropPriority existed and was never read — the engine committed the shred
   defect the document condemns
7  a representation did not inherit its declaring box's drop and min_w, so any
   box with reps was invisible to the drop pass
```

## Distribution

**Largest remainder, ties by DECLARATION ORDER.** Integer centring rounds down. **`Fixed` is
a floor.** No fractional cells.

## The refusals — they are part of the contract

**No margin. No `order`. No baseline alignment. No fractional cells.** Each has a recorded
reason in `LAYOUT_ENGINE.md`. Implementing one is a spec violation, not a feature.

## Gate

```
unit suite green
the property set green (see 08)
A FLOAT MOVES ZERO FRAMES   <- the strongest single gate available.
                               A float takes no space and is skipped by every
                               sizing pass. Any mover means it is in the flow.
```
