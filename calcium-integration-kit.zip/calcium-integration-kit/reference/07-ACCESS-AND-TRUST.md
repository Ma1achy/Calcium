> **Reference input** for the integration tasks. Where this file and the repository differ,
> the task that cites it decides. It is not an instruction on its own.


> **`status: approved-plan`** — and it is re-sequenced BEFORE components.
> **The registry is the only normative source.** Where this file and
> `source/calcium-registry.json` disagree, **the registry wins.**

# 07 · Accessibility and the trust boundary

> **⚠ RE-SEQUENCED.** This was phase 5. **It is now PHASE 3, before components.**
> Components are required to have linear forms and pass the carrier gate, and those are
> defined here — so defining them afterwards was circular. **And untrusted content is
> rendered long before the escape boundary existed**, which is a security hole rather than
> an ordering preference. See `ROADMAP.md`.

**These two are ABSENT rather than confused, which makes them the riskiest to leave late.**
Everything else in this specification is a rule that exists and may be wrong. These are rules
that do not exist yet.

## The semantic node model

**Every element emits a semantic node, independent of its cells.**

```
role · name · value · state · set position · actions
```

**Announcement policy with deduplication** — a streaming answer must not announce every
token, and a re-solve must not re-announce an unchanged region.

**Plots and images need three things**: a summary, a data view, and a long description. **A
picture with no data view is unreachable**, and this framework draws a lot of pictures.

## The linear render mode

```
append-only \u00b7 no cursor addressing \u00b7 no repaint
```

**One mode buys three things at once**: screen readers, `script`/CI capture, and piping a
session to a file. It fits the capability ladder exactly — *a capability makes things better,
never possible*.

**Open question worth deciding before you build it**: linear as a MODE shares the state tuple
and the semantic nodes, which is what makes it cheap. **But it cannot share the layout engine,
because it has no cells.**

## The trust boundary

**Only the renderer emits terminal control sequences.**

**Everything below is DATA and must be escaped**, for ANSI, OSC, bidi controls, forged
hyperlinks, title changes and clipboard sequences:

```
model text \u00b7 filenames \u00b7 branch names \u00b7 URLs \u00b7 log content \u00b7 tool output
commit messages \u00b7 anything from the network \u00b7 anything from disk
```

**OSC 52 is a clipboard mechanism, not text.** Model output containing an OSC 52 sequence must
never reach the terminal as a control.

**An attached PTY interprets controls ONLY inside its own boundary** — a child writing a title
change or a clipboard sequence must not escape its region.

**Build a malicious-content fixture suite.** Every escape class, every surface that displays
untrusted text. This is the one area where a missing test is a security hole rather than a
visual bug.

## Three histories — and this fixes revert-after-compaction

```
the EVENT RECORD      durable, on disk, NEVER evicted. Find falls through to it
the RENDERED WINDOW   what is on screen. Evicts, and SAYS WHAT IT DROPPED
the MODEL CONTEXT     what the model sees. COMPACTION CHANGES THIS
```

**Compaction changes the model context and does not delete the record.** Revert currently
promises undo for patches the transcript summarised away; with three histories it does not
have to.
