> **Reference input** for the integration tasks. Where this file and the repository differ,
> the task that cites it decides. It is not an instruction on its own.


> **`status: approved-plan`** — the state contract below is GENERATED from `R-STA-001`
> and `R-STA-002`. The component specifications are decided, not built (phase 6).
> **The registry is the only normative source.**


# 06 · Components

**Appearance is law.** Every Calcium app looks like a Calcium app. A theme swaps the palette,
never the grammar. **An app does not decide how a chip looks; it decides what it puts in one.**

## The component contract

**Every interactive component declares:**

```
states                the state tuple (below)
owner                 which rung it raises, if any
actions               with routing verdicts, per action
copy format           what \u2303\u21e7C takes — the SOURCE, never the rendering
representations       responsive, WIDTH AND HEIGHT
capability forms      1-bit \u00b7 ASCII \u00b7 motion-off \u00b7 linear
at least one real consumer
```

## The state tuple

**`R-STA-001` — the orthogonal axes. No generic `active` flag is stored.**

```
 1  Lifecycle
 2  outcome
 3  resolution
 4  ownership
 5  focus
 6  pointer
 7  selection
 8  choice
 9  disclosure
10  availability
11  freshness
12  validity
```

**An earlier draft named six axes and called them the tuple.** Six is a subset of twelve, so
implementing from it gives the wrong state space — and *no generic active flag* is the rule
that six-axis version quietly broke.

## Ground precedence

**`R-STA-002` — a cell has ONE ground. The precedence, in order:**

```
1  owner or armed
2  copy selection
3  focus
4  hover preview
5  semantic extent
6  structural surface
```

**Displaced facts retain a mark, an edge, or weight.** That is what keeps the two-carrier
rule true when the ground is taken — selection keeps its mark when focus takes the ground,
and syntax never competes for a ground at all.

**Six cases must be drawn, because each has been drawn inconsistently**: focused+selected+
failed · hovering one link while another has keyboard focus · selection over a diff ground ·
focus over a heatmap ground · disabled+error · stale+running.

## The primitives

**32 primitives, per the registry.** `source/calcium-primitives.html` shows 25 and the
list below shows 27 — **both are stale. The registry count is the count.**

```
GUTTER · MARK · CHIP · RULE · WASH · LADDER · TAPE · RESIDUE · STATUS
BAR · SPINNER · RAMP · SCROLLBAR · SPAN · WIDGET · TABLE · LINK · BLOCK
CALL · PANEL · PEEK · OVERLAY · TREE · FORM · SPLIT · PALETTE · TOAST
```

**`CALL` is the one to internalise: a command's OUTPUT IS the call grammar.** There is no
separate shape. A shell command, an HTTP request, a migration and a build step are all a unit
of work whose output belongs to it.

```
\u25cf MARK       a work unit \u00b7 the COLUMN says whose
  VERB       what was done \u00b7 Fixed, and it NEVER truncates
  ARGUMENT   what it was done to \u00b7 truncates in the MIDDLE
  DURATION   or the spinner, while it runs
  OUTCOME    in the RESULT'S OWN UNITS — lines, hits, rows, bytes
\u23bf OUTPUT     bounded, with a residue row
```

## Shedding — and four kinds get this wrong today (C09 I81)

**Truncation is for ONE RUN too long for its box. Shedding is for a ROW OF PEERS too many for
the width.** Four kinds apply truncation to a shedding problem, which is why every column
gives at the same moment.

**RANK 0 NEVER SHEDS:**

```
comparison   the two VALUES — without them it is not a comparison
keyValue     the KEY — a value with no key is not a fact
events       the TIME and the mark
steps        the CURRENT step
```

**An all-or-nothing group goes before any single member.** Every elapsed time goes before one
agent does, because knowing an agent exists beats knowing how long it has run.

## Meters

```
quantity       capacity | progress | count
granularity    continuous | segmented
liveness       still | active | stalled
```

**A training run is `progress` + `continuous` + `active`** — which budget-versus-operation
could not express.

## Owed a full contract

**Tree · Form · Split · Palette · Toast · Link · Editor · Collection/Menu · Disclosure ·
Tab/Frame.** Fourteen components have a seven-field state table; these ten do not.
