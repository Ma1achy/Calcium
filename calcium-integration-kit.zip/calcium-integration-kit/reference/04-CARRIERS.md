> **Reference input** for the integration tasks. Where this file and the repository differ,
> the task that cites it decides. It is not an instruction on its own.


> **`status: draft`** — the carrier compiler DOES NOT EXIST — see 13.
> **Partly superseded**: the carrier-compiler claim is SUPERSEDED by 13. The animation rules are current.
> **The registry is the only normative source.** Where this file and
> `source/calcium-registry.json` disagree, **the registry wins.**

# 04 · Carriers and capability

> **⚠ THE CARRIER COMPILER DESCRIBED BELOW DOES NOT EXIST.** `checkCarriers` lints CSS
> keyframe properties — which is a good check, and not a semantic carrier gate.
> **See `13-CARRIER-MATRIX.md` for what must actually be built.** The animation rules in
> this file are current and correct.

**The document's most-repeated rule is "every distinction survives to 1-bit".** This is the
test that makes it real rather than remembered.

## The carrier compiler

```
declare a semantic fact ONCE
assert it keeps TWO INDEPENDENT CARRIERS at every rung:

  full colour · 8-bit · 1-bit · ASCII · motion-off · reduced-motion · linear
```

**Two independent carriers** means glyph + tone, or glyph + position, or tone + text — never
two that die together. **A ground is never the only carrier.**

## The rungs

```
capability     makes things BETTER, never POSSIBLE
1-bit          no tone at all — the glyph and the text must carry everything
ASCII          every glyph has a fallback, and WIDTH IS CHECKED ON A SET
motion: off    every live thing shows an ELAPSED COUNT, so nothing is lost
motion: reduced  continuous shimmer, flicker, neon, marquee and cursor blink
                 stop. One-shot meaningful transitions REMAIN
linear         append-only, no cursor addressing. Buys screen readers,
               script/CI capture, and piping a session to a file
```

## The animation rule — this is a hard constraint, not a style

**An animation is legal if it changes WHAT COLOUR A CELL IS or WHICH GLYPH IS IN IT. Nothing
else exists.**

```
LEGAL      colour · opacity · brightness · a glyph swap within one cell
ILLEGAL    transform · translate · scale · rotate · sub-pixel displacement
```

**A previous revision of this specification used `translateY(-.08em)` for the shimmer.** A
terminal cannot move a glyph within a cell. **The shimmer is a TONE effect**: each character
is its own span with a staggered delay, and they brighten in sequence — the travelling
highlight is produced entirely by tone.

**Grep the generated CSS for `transform` in any keyframe. It should find nothing.**

## The glyph registry

**12 canonical glyphs, each with:**

```
unicode · ascii · semanticRole · tone · widthByCapability · reservedCells
collisionDomains · accessibleName · status · ruleIds · canonical · widthClass
```

**`reservedCells` catches the real bug**: `\u23bf` is a ONE-CELL mark whose ASCII fallback
`` `- `` is TWO cells. A fallback wider than its slot shifts every column after it.

**`collisionDomains` catches the other one**: three distinct marks must never share one ASCII
fallback. **Zero collisions today — keep it that way.**

## Contrast

**Generated, never hand-picked.** Every tone × every surface × every theme, plus CVD
simulation, plus a dedicated `focusIndicator` token tested against its SURROUNDINGS.

**The scoping error has happened twice here**: tones were audited against the terminal
background, then against `focusGround`, and `selection` was in neither sweep.

```
nord meta on base         4.41:1     PASS
nord meta on selection    2.70:1     FAIL
nord info on selection    2.84:1     FAIL
nord muted on selection   2.91:1     FAIL
```
