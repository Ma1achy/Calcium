> **Reference input** for the integration tasks. Where this file and the repository differ,
> the task that cites it decides. It is not an instruction on its own.


> **`status: approved-plan`** — this corrects `04-CARRIERS.md`.
> **The carrier compiler does not exist.** This file says what it must be.

# 13 · The carrier matrix

**`04-CARRIERS.md` presents the carrier compiler as if it were implemented. It is not.**

**What exists** is `checkCarriers` in `check-calcium.mjs`: it validates that keyframes use
only legal CSS properties, and checks several exact ramp strings. **That is a good animation
lint and it should stay.** It is not a semantic carrier gate and must not be described as one.

## What is missing

**A structured fact-by-capability matrix for the compiler to compile.** Today there is
nothing to compile.

```json
{ "factId": "F-CALL-RUNNING",
  "statement": "this call is currently running",
  "carriers": {
    "24bit":    ["spinner:braille", "tone:accent", "text:elapsed"],
    "8bit":     ["spinner:braille", "tone:accent", "text:elapsed"],
    "1bit":     ["spinner:braille", "text:elapsed"],
    "ascii":    ["spinner:ascii",   "text:elapsed"],
    "motionOff":["text:elapsed",    "glyph:\u25cf"],
    "reduced":  ["text:elapsed",    "glyph:\u25cf"],
    "linear":   ["text:elapsed"]
  } }
```

## The assertion

> **EVERY FACT KEEPS TWO INDEPENDENT CARRIERS AT EVERY RUNG.**

**Independent means they do not die together.** Glyph + tone is independent. Tone + ground is
NOT — both die at 1-bit.

**`linear` is the honest exception**: it is a text stream, so one carrier is all that exists.
**State that as a declared exception rather than letting the rule quietly fail there.**

## What this catches that the CSS lint cannot

```
a fact carried ONLY by tone                   dies at 1-bit
a fact carried by tone AND ground             both die at 1-bit
a fact carried ONLY by motion                 dies at motion:off
a fact whose ASCII rung drops its second carrier
a NEW fact added with no carriers declared at all
```

**That last one is the important one.** The matrix makes adding a fact without carriers a
build failure, which is the only way the rule stays true as the framework grows.

## Where the facts come from

**The registry already has them, unlabelled** — every `current` rule that says a state is
distinguishable is a fact. **Extract them rather than authoring a second list**, or the matrix
becomes the next thing to drift.

## Gate

```
every fact has \u2265 2 independent carriers at every rung except linear
linear is declared as a one-carrier exception, per fact
no fact exists without a carrier declaration
```
