> **Reference input** for the integration tasks. Where this file and the repository differ,
> the task that cites it decides. It is not an instruction on its own.


> **`status: draft`** — the three actions are REGISTERED; the R-SEL-* rules are not.
> **The registry is the only normative source.** Where this file and
> `source/calcium-registry.json` disagree, **the registry wins.**

# 10 · Selection

> **REGISTERED in 0.6.** The three actions and their bindings are in the registry.
>
>
> **THREE ACTIONS, ALLOCATED. This supersedes every chord named below.**
>
> ```
> copy                 ⌃⇧C   copy the SOURCE of what is focused      SHIPPING
> selection.native     ⌥⇧C   hand the mouse to the TERMINAL          SHIPPING
> selection.semantic   ⌥⇧V   enter Calcium's own copy mode           NEW
> ```
>
> **These are three different actions and each keeps its own chord.** Native handoff
> gives the mouse AWAY; semantic copy mode TAKES it. Reusing one chord for two of
> them was the contradiction this file carried for four revisions.
>
> **Phase 0.6 registers all three** — action records, one binding each, in
> `default-terminal`. It is NOT deferred to 2.1: everything else in phase 0 is
> blocked on it, so scheduling it later was circular.

**Half of this existed: spans as a substrate, `anchor`/`member` in the state tuple, copy mode
as a rung, and *copy takes the SOURCE, never the rendering*. The interaction did not.**

**And underneath it is the one place where a stated rule and the platform actively
disagree**, rather than merely being unspecified.

---

## 1 · There are TWO selections, and only one of them is ours

```
the EMULATOR'S     the user drags with the mouse. The terminal selects
                   RENDERED CELLS — gutter marks, box borders, truncation
                   ellipses, the scrollbar column, everything.
                   We cannot see it, style it, or read it.

COPY MODE          ours. It selects SOURCE, knows what a block is, and
                   respects entry boundaries.
```

**This contradicts `copy takes the SOURCE, never the rendering` outright**, because the
emulator will happily hand the user a paragraph with `⎿ ` and a `│` down the middle of it.

### The rule

> **WE DO NOT FIGHT THE EMULATOR FOR THE MOUSE, AND WE DO NOT PRETEND ITS SELECTION IS OURS.**

**Mouse selection belongs to the terminal.** It is muscle memory a decade deep, it works
across panes and multiplexers, and taking it means taking every mouse event forever.

**So the rule scopes rather than breaks:**

```
copy takes the SOURCE   — for every copy CALCIUM performs
                          (⌃⇧C direct copy, ⌥⇧V copy mode, a copy affordance on a block)
```

**And the framework earns the difference rather than asserting it.** Two obligations follow.

### Obligation 1 — the render must survive a naive drag

**Because a drag WILL happen and we cannot stop it**, the rendering has to be worth copying.

```
· a wrapped line's continuation carries NO decoration in the gutter
· a bounded block's content does not sit inside vertical rules
· the scrollbar is the LAST column, so a drag that stops short of it is clean
· nothing meaningful is ever drawn in a column a reader would not drag through
```

**This is a real constraint on layout, not a note.** It is why the gutter is two cells and
why continuation rows are blank there.

### Obligation 2 — offer the better copy where the worse one is likely

**When the emulator's selection is active, Calcium cannot know.** But it CAN know that a
block is focused and expensive to copy badly.

```
a block with a copy affordance shows it on FOCUS, not on hover
    ⌃⇧C copy source
```

**Never a toast, never a hint that appears on drag** — we cannot detect the drag, and
guessing produces a hint that fires at the wrong time.

---

## 2 · Copy mode — the rung, made concrete

**`⌥⇧V` from anywhere. It is rung 2 of the ladder: it takes every key and the screen
freezes.**

```
enter      ⌥⇧V · or ⏎ on a block's copy affordance (which pre-selects it)
leave      esc · or ⏎, which copies AND leaves
```

### What is frozen, and what is not

**The frame stops painting. Three things still redraw**, because a frozen owner that consumes
everything is the one rung whose state the reader cannot otherwise see:

```
1  the mode label in the footer
2  the selection itself, as it extends
3  the count — "418 chars · 9 rows · 2 entries"
```

**Nothing else. Not the spinners, not the elapsed counts, not arriving content.** Content
that arrives while frozen is buffered and lands when copy mode exits, and **the footer says
so**: `⌥⇧V copy · 3 entries arrived`.

### The keys

```
← → ↑ ↓          move the CARET. No selection yet
⇧ + arrows       extend from the ANCHOR
⌥← ⌥→            by word
⇧⌥← ⇧⌥→          extend by word
⌘← ⌘→            line ends
⇧↑ ⇧↓ at an edge scroll, and keep extending
v                start a selection at the caret without ⇧ (vi muscle memory)
V                extend to WHOLE ROWS
⌃V               RECTANGULAR — see §5
a                select the ENTRY under the caret
A                select ALL LOADED entries — see §6
⏎                copy, and leave
esc              see §4
```

**`v`, `V`, `a`, `A` are single-letter commands and that is legal here** — copy mode is a
scope where typing is impossible, which is exactly what the single-key rule permits.

---

## 2a · Drag, autoscroll, and WHICH container moves

**Outside copy mode the mouse is the emulator's, and so is its autoscroll.** We do nothing.

**Inside copy mode we own everything, including the mouse** — that is what "it takes every
key" means once a pointer exists. So drag-to-extend is ours, and edge-drag must autoscroll.

### The rule, and it is NOT the wheel's rule

> **THE CONTAINER THAT SCROLLS IS THE ONE THE ANCHOR IS IN — not the one under the pointer.**

**This is the one place the pointer does not decide**, and the reason is that a drag is a
single continuous gesture with an origin. You started selecting inside a chip preview; you
drag downward past its edge; **the panel scrolls, not the transcript underneath it**. If the
pointer decided, leaving the panel's rect would scroll something your selection is not in,
and the selection would stop extending at the exact moment you asked for more of it.

```
the WHEEL      the innermost scrollable under the POINTER, highest layer first
the ARROWS     the scrollable you are INSIDE
a DRAG         the scrollable the ANCHOR is in — for the whole gesture
```

**The anchor binds the gesture to a container the way press-arms binds it to an element.**
Same principle, one axis over: **a gesture belongs to where it started.**

### Rate

```
within the rect        no scroll
0–1 cells past         1 row per 120ms
1–4 cells past         1 row per 60ms
more than 4 past       1 row per 30ms
```

**Three bands, because two is too coarse to control and a continuous ramp is impossible to
stop where you meant.** Horizontal autoscroll uses the same bands on columns.

**The scroll continues while the button is held and the pointer is outside**, even if the
pointer stops moving. **It stops on release, on esc, or at the end of the container** — and
at the end it stops rather than rubber-banding, because there is nothing to rubber-band
against in a cell grid.

### At the end of the container

**The selection extends to the container's end and stays there.** It does not spill into the
parent.

**Which follows from §3**: a block is atomic, and a scrollable container is a boundary for the
same reason — you are selecting *in* something, and leaving it is a new gesture rather than a
continuation of this one.

### Keyboard extend does the same thing

**`⇧↑` and `⇧↓` at an edge scroll the container the ANCHOR is in**, which is the same rule
arriving from the other input. **Focus pulls the viewport, by the minimum** — and so does an
extending selection, for the same reason: *the thing you are manipulating must stay visible.*

### The count keeps up

**The count in the footer updates while autoscrolling**, because it is one of the three things
that redraw while frozen (§2). **A selection growing at 30ms per row with no feedback is a
selection you cannot stop at the right place.**

### Passing THROUGH a scrollable container

**The case that is not the one above**: your anchor is in the transcript, and the drag runs
down through a bounded block that has its own scrollbar, and out the other side.

> **A CONTAINER YOU PASS THROUGH IS TAKEN WHOLE. IT DOES NOT SCROLL.**

**It does not scroll because your anchor is not in it** — §2a already decides that. And it
is taken whole because §3 already decides that: **a block is atomic.** A scrollable block is
a block.

**Which has a consequence worth stating out loud, because it is better than the alternative
and will look like a bug otherwise:**

```
● help · 212 keys
  ⎿ ⇥        complete, in the prompt              █
    ⇧⇥       out of the prompt                    █
    esc      resolve the innermost state          ░
    ⋯ 209 more   ↵ expand
```

**Dragging through this takes ALL 212 ROWS, not the three on screen.** The residue row said
there were 209 more; the copy gives you them. **The window is rendering; the source is the
block.**

**If you wanted only what you can see, that is `⌃V` — rectangular, which copies CELLS and
says so (§5).** The two gestures mean different things and now both are reachable.

### Leaving and re-entering

**All-or-none applies continuously, not just at the end of the gesture.**

```
drag DOWN into the block        the whole block joins the selection
keep dragging PAST it           the block stays, prose below joins
drag back UP above the block    the block LEAVES the selection entirely
```

**A block never appears partially at any point during the drag**, so the count never shows a
size that no release could produce. **The count is always the size of what ⏎ would copy right
now** — which is the property that makes the count worth watching.

### And the nested case

**A container inside a container, both scrollable, and the anchor above both.** Same answer,
applied twice: **the outermost block you pass through is taken whole**, which includes its
children. You never reason about the inner one, because you never get to address it.

**The only way to select INSIDE a bounded block is to start there** — and then §2a applies,
and that block is the one that scrolls.

**That is the whole model in one sentence:**

> **WHERE YOU START DECIDES WHAT YOU CAN ADDRESS. Everything you merely cross is taken whole.**

---

## 3 · Selection over a block boundary

**The hard case: a drag or an extend that starts in a paragraph and runs through a plot, a
table or an image.**

```
                    what the SOURCE copy takes
prose               the text, unwrapped, with soft wraps removed
a code block        the code, with its original indentation
a patch             the PATCH, in unified diff form — not the rendered
                    two-column view
a table             TSV. Rows and columns, with the header
a plot              its DATA, as the block's data view (07) provides
an image            its ALT TEXT, and its path if it has one
a live terminal     the scrollback as text, at the moment of the copy
```

### The rule

> **A BLOCK IS ATOMIC IN A SELECTION. You take all of it or none of it.**

**Partially selecting a plot is meaningless**, and a half-table is worse than no table. So an
extend that reaches a block takes the whole block and continues past it.

**The visual consequence, and it must be drawn**: the block gets the selection ground on its
FRAME or its first row, not on every cell of its body. **A plot with a selection wash over its
axes is unreadable, and unreadable is a failure even when it is correct.**

### Order and separators

**Copy is in DOCUMENT ORDER, and entries are separated by a blank line.** A block's own
content is not re-indented to match its rendered inset — **the inset is rendering.**

---

## 4 · esc, and what a selection is

**This was open. Here is the decision.**

> **esc CLEARS THE SELECTION IF THERE IS ONE. A SECOND esc LEAVES COPY MODE.**

**Because a selection is a temporary state inside copy mode**, and *esc resolves the innermost
temporary state* — it would be inconsistent for the selection to survive an esc that pops its
container.

**And it is forgiving**: the common error is selecting the wrong range, and the common fix is
starting again without losing your scroll position.

**Two esc presses to leave from a selection is not a violation of *esc pops exactly one
rung***, because **the selection is not a rung** — it is state within one. The footer says
which press is next:

```
with a selection     ⌥⇧V copy · 418 chars · esc clears · ⏎ copies
with none            ⌥⇧V copy · esc out · the screen is frozen
```

---

## 5 · Rectangular selection

**A table makes this obvious to want, and it is cheap once the grid exists.**

```
⌃V           toggle rectangular
the ground   every cell in the rect, which is what a rect IS
copy         each row's slice, newline-joined
```

**The one rule that keeps it honest:**

> **A RECTANGULAR SELECTION COPIES CELLS, NOT SOURCE — and it says so.**

```
⌥⇧V copy · RECT 12×4 · cells, not source
```

**This is the single exception to *copy takes the source*, and it is explicit rather than
silent.** A rectangle over rendered columns is a request for exactly what is on screen — that
is what the gesture means, and pretending otherwise would make it useless for its one real
purpose, which is pulling a column out of a table.

**A rectangular selection never crosses a block boundary.** It clips to the region it started
in.

---

## 6 · Select-all — and ALL of what?

**Three plausible answers, so name them all:**

```
a        the ENTRY under the caret — the common case, and the cheap one
A        ALL LOADED entries — what is in the rendered window
⌃A       nothing. It is not bound
```

**`A` says what it did, because the window is not the record:**

```
selected 41 entries · the loaded window · 218 more in the record
```

**There is deliberately no key for "select the whole record".** The record is on disk and can
be megabytes; a key that silently produces a 40 MB clipboard is a trap. **`/export` is the
path for that**, and it writes a file rather than a clipboard.

---

## 7 · Selection and focus — the ground conflict

**Both want the ground, and Calcium permits ONE ground per cell.** This resolves the
precedence that `06` declares.

> **SELECTION OWNS THE GROUND. FOCUS KEEPS ITS MARK.**

```
rest              no ground · no mark
focused           focusGround · ▸
selected          selectionGround · no mark
focused+selected  selectionGround · ▸ KEPT
```

**Because a selection is transient and deliberate** — you made it a second ago and you are
about to act on it — **while focus is ambient**. The thing you just did wins the loud channel,
and the ambient thing keeps a carrier.

**Which satisfies the two-carrier rule**: focus survives as `▸`, selection survives as the
ground, and at 1-bit selection becomes reverse video while `▸` persists.

### And over a diff ground

**Selection still wins the ground**, so an added line inside a selection loses its green.
**The `+` and `−` marks carry it**, which is why they exist — the diff was never ground-only.

---

## 8 · What copy mode is NOT

**It is not find.** Find has its own rung and its own keys; entering copy mode from a find
result keeps the match marks but does not select them.

**It is not navigation.** The caret moves in copy mode, focus does not. **Leaving copy mode
returns focus exactly where it was**, which is the same guarantee a resize makes.

**It is not a viewer.** `⌥↑↓` still scrolls, because it is read before the ladder — but the
content does not update, so what scrolls is the frozen frame.

---

## 9 · The clipboard

**One clipboard, two mechanisms:**

```
local        the OS clipboard, when Calcium is on the same machine
OSC 52       when it is not — and OSC 52 IS A CONTROL SEQUENCE, so it is
             emitted ONLY by the renderer and never from content (07)
```

**If neither is available, say so rather than failing silently:**

```
⌥⇧V copy · no clipboard · ⏎ writes /tmp/calcium-copy-4a1f.txt
```

**A copy that appears to work and does not is the worst outcome available here**, because the
user will not notice until they paste.

---

## 10 · What this adds to the registry

**15 rules, and two supersede existing ones. NONE OF THEM EXIST IN THE
REGISTRY YET — this file is `draft` until they do.**

```
R-SEL-001  two selections, and mouse belongs to the emulator
R-SEL-002  the render must survive a naive drag        [layout constraint]
R-SEL-003  a block is ATOMIC in a selection
R-SEL-004  a block's copy form, per kind
R-SEL-005  esc clears the selection; a second esc leaves the rung
R-SEL-006  selection owns the ground, focus keeps its mark
           supersedes the ambiguity in R-STA-002
R-SEL-007  rectangular copies CELLS, and says so       [the one exception]
R-SEL-008  a · A · and no whole-record key
R-SEL-009  three things redraw while frozen
R-SEL-010  buffered arrivals are announced on exit
R-SEL-011  no clipboard is stated, never silent
           promotes R-EXA-044 from example to current
R-SEL-012  a DRAG scrolls the container the ANCHOR is in — the one place
           the pointer does not decide
R-SEL-013  three autoscroll bands, and it stops at the container's end
R-SEL-014  a container you PASS THROUGH is taken whole and does not scroll
R-SEL-015  all-or-none applies CONTINUOUSLY — the count is always what ⏎
           would copy right now
```

## 11 · Tests

```
UNIT         every block kind's copy form, against a fixture
             a soft wrap is removed; a hard newline is kept
PROPERTY     a selection never contains part of a block
             copy output round-trips: parse(copy(entry)) == entry, for
             code, patches and tables
INTEGRATION  drag-extend out of a PANEL: the panel scrolls, not the
             transcript beneath it
             autoscroll stops at the container end and does not spill
             drag THROUGH a bounded block: all 212 rows, not the 3 shown
             drag back out: the block leaves the selection entirely
             nested scrollables: the outermost is taken, the inner is
             never addressable
             extend through a plot, a table and an image in one range
             copy mode entered from a find result
             content arrives while frozen, and lands on exit
E2E          leaving copy mode restores focus exactly
             a selection survives a scroll and dies on esc
CARRIER      selected+focused at 1-bit: reverse video AND ▸
             selection over a diff: the ground goes, + and − remain
```
