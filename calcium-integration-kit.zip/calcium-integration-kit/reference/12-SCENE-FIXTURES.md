> **Reference input** for the integration tasks. Where this file and the repository differ,
> the task that cites it decides. It is not an instruction on its own.


> **`status: approved-plan`** — this supersedes `03-FRAME-COMPARISON.md` §"The harness".
> **The registry is the only normative source.**

# 12 · Scene fixtures — executable inputs, not output snapshots

**The 109 fixtures in `fixtures/` are OUTPUTS.** `INDEX.json` carries dimensions, a SHA and
rule IDs — **and no scene tree, state, theme, capability vector, locale, clock or setup
actions.** *"Build the scene the fixture describes"* is not an instruction a machine can
follow.

**They are still useful as a smoke test.** They are not an acceptance gate.

## What a scene fixture is

```json
{
  "id": "agent-at-work-96",
  "ruleIds": ["R-SEC-014", "..."],
  "scene": { "$ref": "scenes/agent-at-work.json" },
  "viewport": { "cols": 96, "rows": 31 },
  "theme": "dark",
  "capability": { "colour": "24bit", "unicode": "full",
                  "motion": "full", "mouse": true },
  "locale": "en-GB",
  "clock": { "frozen": "2026-09-18T22:13:00Z" },
  "setup": [ { "key": "Tab", "shift": true }, { "key": "ArrowDown" } ],
  "expect": {
    "cells":  "expected/agent-at-work-96.cells.json",
    "plain":  "expected/agent-at-work-96.txt",
    "frames": ["expected/agent-at-work-96.t0.cells.json",
               "expected/agent-at-work-96.t120.cells.json"]
  }
}
```

**`scene` is a tree the renderer can construct.** Everything else is the environment it is
constructed in. **Without these fields a fixture is a photograph, not a test.**

## Styled cells, not plain text

**The plain-text comparison cannot catch a monochrome implementation, a broken shimmer, a
wrong cadence or a generic replacement spinner.** Those are four of the most likely failures
and the current harness is blind to all of them.

```json
{ "row": 3, "col": 12,
  "glyph": "\u25cf", "fg": "ok", "bg": null, "bold": false,
  "animated": { "setId": "braille", "intervalMs": 80 } }
```

**Compare the token names, never the resolved hex.** A theme swap must not move a fixture.

## Animated cells — coordinates and a set ID

**`\u2726` as a wildcard is wrong twice**: it has no position, and **`\u2726` is also legitimate
static content** (the model mark in the header).

```
every animated cell carries { row, col, setId }
the comparison asserts: the glyph at that cell is a MEMBER of setId
a static \u2726 asserts EXACTLY \u2726
```

## Time sampling

**Cadence is a fact and must be tested.**

```
render at t=0 and t=interval and t=2\u00d7interval with a FAKE CLOCK
assert the glyph ADVANCED, and advanced by ONE frame
assert it is the set the registry names \u2014 not "a spinner"
```

**A generic replacement spinner passes every plain-text test and fails this one**, which is
the point.

## Coverage — one snapshot per section is not enough

**A section has many responsive states and this kit has one frame each.**

```
per scene:  the widths where its representation CHANGES, from the registry
            \u2014 not three widths someone picked
            plus the height where chrome starts shedding
            plus 1-bit, ASCII, motion-off, and linear
```

**Generate the width list from the scene's own thresholds.** A hand-picked width tests
whatever the author was thinking about.

## Known defect in the current index

**The "40 columns" specimen is indexed at 66 cols**, because the section's frame block is
wider than the scene it describes. **Scene fixtures fix this by construction** — the viewport
is declared, not measured off the output.

## What to build

```
1  a SCENE SERIALISER — dump any built tree to scenes/*.json
2  a FIXTURE GENERATOR — scene \u00d7 environment \u2192 expected/*
3  a TARGET HARNESS — run the real TUI against a scene, capture styled cells
4  a DIFF that reports the first differing cell and the two rows around it
```

**None of these exist yet. They are phase 2.**
