> **Reference input** for the integration tasks. Where this file and the repository differ,
> the task that cites it decides. It is not an instruction on its own.


> **`status: approved-plan`** — reconciled against R-OWN-003.
> **The registry is the only normative source.** Where this file and
> `source/calcium-registry.json` disagree, **the registry wins.**

# 05 · Navigation, ownership and input

**Read**: `source/calcium-navigation.html` (13 sections) and `historical/CONTRACTS.md` §2–3 (quarantined).
**A live implementation is in `source/calcium-interaction-prototype.html`.**

## The question is not where is focus — it is WHO OWNS THE KEYBOARD

**Exactly one thing does, at every moment.**

```
owner        raised by              takes                 leaves by
the CHILD    an attached PTY        every key, ⌃C too    ⌥esc detaches
COPY MODE    ⌥⇧V froze the screen  every key             esc, or a copy
a MODAL      a choice question      ←→ ⏎ esc             ⏎ · esc answers SAFE
a SUBSTATE   find · completion ·     its own, then the     esc closes the
             a typed reply          prompt's              SUBSTATE
the INSIDE   a camera · a cursor    ←→ ↑↓ and letters    esc leaves it
the SCOPE    prompt · transcript    everything else       esc out one rung
```

**A rung takes what it declares and passes the rest DOWN, never up. Esc pops EXACTLY ONE
RUNG.**

## Verdicts, per owner per action

```
handle             it acts
reject             it refuses, OUT LOUD, naming why — never silently
pass               it goes DOWN one rung
global-intercept   read BEFORE the ladder
```

**Three keys are global-intercept and an app cannot add to the list:**

```
⌃C         stop the turn — or reach the CHILD, when one is attached
⌥↑ ⌥↓      scroll. Focus never moves
the wheel   the same, wherever the pointer is
```

## Arrival splits in two — this resolves the contradiction

```
CONTENT arrival        a patch, an entry, a RESIZE. A RENDER event.
                       IT NEVER CHANGES THE OWNER.
OWNERSHIP-REQUEST      a question, an attach, copy mode. It RAISES a rung,
                       and the rung ARMS.
```

## Input ownership — the safety rule

**Events assigned to one owner must not be replayed against another. A newly presented
question requires a FRESH, DELIBERATE activation.**

**Without key-release reporting you cannot know a key was held across the handoff**, so the
policy is conservative: the question **arms** on arrival and the first activation after it is
refused out loud, naming why.

**The prompt's whole state is held and restored exactly** — buffer, caret, selection, chips,
undo. *One line-editor implementation* is right; *one line-editor state* is not.

**The safe choice is the SELECTED choice.** Deny, not approve.

## Focus

**Document order, never a declared sequence.** A declared order is a second source of truth
that drifts the moment the tree is reordered, and the failure is silent.

**A part that sheds takes its focus with it** — focus falls to the nearest surviving part in
declaration order, and **if the `+n` that replaced it is on screen, focus lands there**.

**Focus is a MARK plus a GROUND**, and the ground narrows as you go deeper: the whole entry in
the transcript, the row once you are inside it.

## Activation

**`R-OWN-003` is the contract. `historical/INTERACTION.md` says press acts and release does
nothing — SUPERSEDED. The prototype acts on `mousedown` with no release handler and is
WRONG; read it for the engine, not for this.**

```
DIRECT-ACTION    press ARMS, release COMMITS
FOCUS-FIRST      the first click focuses; a later click activates
ENTERABLE        ⏎ goes INSIDE, and the arrows then drive it
```

**One state machine, and it is the first thing to write a test for:**

```
on PRESS     arm (stableId, ownerEpoch, x, y)
on RELEASE   commit ONLY IF  stableId matches
                        AND  ownerEpoch matches
                        AND  the pointer is still over that element
CANCEL on    a drag beyond threshold · a second press · an owner change
             · blur · a release elsewhere
```

**`ownerEpoch` is what makes this safe across a handoff.** A question arriving between press
and release changes the epoch, so the release cannot commit. **That is the pointer's version
of the arming rule, and the two must share ONE epoch counter.**

**Bind the gesture to the element's IDENTITY, not the coordinates** — a sorted table can
reorder under a held pointer.

## Scroll

**The wheel goes to the innermost scrollable under the POINTER, highest layer first. The
arrows go to the one you are INSIDE.**

> The pointer says where it is; the keyboard does not.

**Layer order `overlay › panel › peek › base` doubles as scroll priority**, so one ordering
does both jobs.

## The three layers

```
a PANEL     floats above the prompt, between a pair of rules. DISMISSABLE
a PEEK      anchored BESIDE an element, and takes NO keys
an OVERLAY  modal, OWNS input. NOT dismissable — an owner is waiting
```

**`blocking` and `dismissal` are INDEPENDENT.** A typed reply blocks AND floats.

**The click that dismisses does not also act** — one gesture, one effect.

## The four coordinate systems

**No two are interchangeable, and every API says which it takes.**

```
storage offset       what the buffer indexes
grapheme index       what the caret moves by, and what ⌫ deletes
model-token index    what per-token values attach to
display-cell column  what layout solves in
```

**This is the riskiest item in the whole build, because a wrong answer here is SILENT.**
