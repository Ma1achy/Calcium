# Calcium design-language integration kit

**Purpose.** Bring the Calcium repository (`github.com/Ma1achy/Calcium`, audited at
commit `42aa78a`) into line with the Calcium design language. The design language is
the new source of truth for **appearance, interaction and navigation**. Where it and
the repository disagree, the design language wins, and the repository's specs change
first.

**This kit is written for a Claude Code agent working inside the repository's
devcontainer.** It does not build a parallel system. Every task names the repository
files it changes, the C-spec sections it amends, and the invariants its tests cite.

```
00-AUTHORITY.md        what overrides what, and how to change a spec
01-RECONCILIATION.md   every known conflict, verified against 42aa78a, with a verdict
KICKOFF.md             the prompt to start the agent with
tasks/T00…T11          one task per MR, in order
design/                the design language itself — lands in the repo as
                       docs/design/language/ in T00
reference/             the earlier implementation spec files, as INPUT to the
                       tasks, not instructions in their own right
```

**The tasks are a suggested split, not a checklist.** The agent plans its own work from
`01-RECONCILIATION.md` and the HTML, and uses only what it needs. See `KICKOFF.md`.

**Loop, per task:** premise check → spec amendment → implementation → tests citing
invariants and rule IDs → `make enforce` and `make test` green → open a green MR →
stop. One task per MR.
