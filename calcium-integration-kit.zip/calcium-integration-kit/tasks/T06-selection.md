# T06 · Selection

Rules: `R-SEL-001…015` — **register them first** from `reference/10-SELECTION.md`.

## Reconcile with `CALCIUM_SELECTION_DESIGN.md`
The repository's document (roadmap entry 15, *designed, not built*) settles two
things the design language keeps: **two selection types and one clipboard**, and C17
§5a's clipboard ruling. It differs on one thing, which the design language decides:
the thing it calls *copy mode* is native handoff (`⌥⇧C`), and semantic copy mode
(`⌥⇧V`) is a real third mode that takes the mouse. Amend that document's §1 in place,
marking the superseded paragraph.

## Scope
Drag autoscroll by **anchor** container, pass-through containers taken whole, a
block atomic in a selection, esc clears then leaves, rectangular copies cells and
says so, `A` selects the loaded window only.
