# T04 · Input arming and pointer activation

Rules: `R-OWN-003`, the arming rule (§O1). Read `reference/05-NAVIGATION.md`
§Activation.

## Spec — C16 and C26
- A newly raised owner **arms**; the first activation after it is refused out loud.
- Pointer: press **arms** `(stableId, ownerEpoch)`; release commits only if both still
  match and the pointer is over the same element. Cancel on drag, second press, owner
  change, blur, release elsewhere. **One epoch counter** shared with keyboard arming.
- The safe default of a question is **deny**.

## Tests
- A held key across a question's arrival never answers it.
- A table re-sorting under a held pointer commits nothing.
