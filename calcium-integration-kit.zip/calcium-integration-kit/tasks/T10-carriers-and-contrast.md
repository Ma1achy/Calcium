# T10 · Carrier and contrast gates

Read `reference/13-CARRIER-MATRIX.md` and `reference/04-CARRIERS.md`.
- Every animation changes a cell's colour, brightness or glyph — nothing else.
- Every semantic fact keeps two independent carriers at every depth down to 1-bit.
- Contrast over every tone × surface × theme, including **selection**; the three
  known `nord` failures on selection must be fixed, not waived.
