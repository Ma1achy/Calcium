# T08 · Glyph and key validation

Carry the validated rules into the repository's own checks (A03 / `make enforce`),
not a side script:
- Glyph registry: `reservedCells`, ASCII fallbacks, **no two marks share a fallback**.
- Keys: bounded grammar (ASCII printables plus explicit named tokens), canonical
  aliases (`pgup ≡ ⇞`), no bare printable where typing is possible unless guarded
  `non-typing`, commands ASCII-only, no `\p{Cf}` or default-ignorables in any
  rendered identifier or label.
