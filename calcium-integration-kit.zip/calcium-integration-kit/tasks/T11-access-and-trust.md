# T11 · Semantic nodes, linear mode, trust boundary

Read `reference/07-ACCESS-AND-TRUST.md`. Only `terminal/escapes.ts` writes escape
sequences (CLAUDE.md already says so) — extend that to **escaping all untrusted text**:
model output, filenames, logs, tool output. OSC 52 is a mechanism, never content.
