# T02 · Spinner sets

**Conflict 5.** Rules: the spinner records in the registry, `R-GLY-001`.

## Do
1. Add `agent` to `SPINNER_SETS` in `src/presentation/blocks/glyphs.ts` from the
   registry record — frames, `intervalMs` 120, and its ASCII fallback. The walk is
   82 frames; its phase is carried in the animation shorthand (`var(--phase)`), never
   as a separate `animation-delay`.
2. Register `braille2 decimal binary4 line balloon arc` in the registry as `current`,
   copying frames and interval **from the repo** — the repo is right about what ships.
3. Regenerate `docs/media/spinner-sets.gif` (it is generated from the table).

## Constraint
`spinnerSetNames()` is a public export. Adding is fine; **nothing is removed**.

## Tests
- One property test: every registry spinner exists in `SPINNER_SETS` with identical
  frames and interval, and vice versa. This is the test that stops the two drifting.

## Accept
Registry and `SPINNER_SETS` agree exactly at **27 sets**; `make design-check` green.
No set is removed — decided, not open.
