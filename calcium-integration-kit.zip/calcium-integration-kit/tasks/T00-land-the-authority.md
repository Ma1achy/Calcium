# T00 · Land the design language and its gates

**Why first:** every later task cites `R-XXX-NNN` IDs. They must resolve inside the
repository before anything can cite them.

## Do
1. Copy `design/` to `docs/design/language/` — `calcium-registry.json`,
   `calcium-design-language-revised.html`, `build-calcium.mjs`, `check-calcium.mjs`,
   `released-baseline.json`, `lint-immutable.mjs`, `fixtures/`, `docs/KEYS.md`.
   Every script resolves paths beside itself; run `node build-calcium.mjs` there and
   confirm the HTML is byte-identical.
   **Rename the builder's keymap output** (`keysOutputPath`) from `docs/KEYS.md` to
   `KEYS.design.md` beside it, so it cannot be mistaken for the repository's
   `docs/KEYS.md` before T03 makes them one.
2. Add Makefile targets, following the existing style (`## comment` for `make help`):
   ```
   design:        regenerate docs/design/language/calcium-design-language.html
   design-check:  read-only — build in memory and byte-compare; check-calcium;
                  lint-immutable. Writes NOTHING.
   ```
   and make `enforce` depend on `design-check`.
3. Add a row to `docs/INDEX.md` and a line to `docs/README.md` stating the precedence
   in `00-AUTHORITY.md`, verbatim.
4. Add one line to `CLAUDE.md` under *The spec is the contract*: the design language
   is normative for appearance, interaction and navigation; C-specs cite its rule IDs.

## Don't
- Do not carry over the kit's old release/staging/journal machinery. The repository's
  CI and `make enforce` are the gate.
- Do not add a dependency. The scripts are plain Node.

## Accept
- `make design-check` passes on a clean tree and fails if the HTML is hand-edited,
  if a released rule's digest changes, or if a supersession link is redirected.
- `make enforce` green, and it now includes `design-check`.
