# T09 · Design fixtures onto the repository's golden frames

The repository already has `make golden` and `make refdiff`. **Do not add a second
harness.** Map `design/fixtures/` (extracted from the design-language HTML) onto the
existing golden-frame mechanism as the target appearance, surface by surface.

Width is measured with `cells()` — the same function the measurer uses — never a
separate width table.
