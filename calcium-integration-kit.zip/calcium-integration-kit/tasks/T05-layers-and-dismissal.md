# T05 · Panel, peek, overlay — C15

Rules: the layer rules in `reference/05-NAVIGATION.md` §The three layers.

## Spec — C15
- `panel` floats above the prompt between two rules, dismissable; `peek` anchors beside
  an element and takes no keys; `overlay` is modal, owns input, not dismissable.
- Layer order `overlay › panel › peek › base` is also scroll priority.
- Click outside the topmost dismissable layer closes it and **the click is consumed**.
- `blocking` and `dismissal` are independent fields.

## Code
`src/viewport/overlay/`. Check whether `kind: "peek"` and `promptUnderMenu` already
exist (CLAUDE.md names both) and extend them rather than adding parallel shapes.
