# T03 · One ownership ladder, one keymap source

**Conflicts 1, 2, 6, 7.** Rules: `R-OWN-*`, `R-KEY-003`, `R-CAP-001`, `R-INT-002`.
Read `reference/05-NAVIGATION.md` first.

## The ladder mapping — amend C16 §3 and A02 §2
```
repository column     design-language rung           note
overlay               modal                          owns input, not dismissable
copyMode              nativeSelection (RENAMED)      the terminal owns the mouse
(new)                 copy                           semantic copy mode, takes every key
pushedView            substate                       its own keys, then the prompt's
interaction           inside                         camera, cursor, crosshair
prompt                scope: prompt
liveBlock             scope: transcript (live)
global                global-intercept               ⌃C, ⌥↑↓, the wheel — read BEFORE the ladder
(new)                 child                          an attached PTY; ⌃] base, ⌥esc enhanced
```
Verdicts per owner per action: `handle · reject · pass · global-intercept`.
**Arrival** splits in two: a content arrival never changes the owner; an
ownership-request raises a rung and **arms**.

## The keymap source
`defaultKeymap` in `src/interaction/router/keymap.ts` becomes **generated data** from
the registry's `actions` and `bindings` (joined by `actionId`). `tools/keymap-table.mjs`
keeps generating `docs/KEYS.md`, now with `Route` and `Condition` columns.

## Chords
`⌃⇧C` copy · `⌥⇧C` selection.native · `⌥⇧V` selection.semantic.

## Tests
- Every current action has a `default-terminal` route (`R-CAP-001`).
- No two routes collide after canonicalisation (modifier order, aliases, case).
- Esc pops exactly one rung; a resize never changes the owner.

## Accept
`docs/KEYS.md` regenerates with the new columns; no chord in it contradicts the
registry.
