# T01 · Grounds on state, and the reverse-video rung

**Conflicts 3 and 4.** Rules: `R-STA-001`, `R-STA-002`, `R-SEL-006` (proposal in
`reference/10-SELECTION.md`, registered in T06).

## Spec first — C10
- **§4c / line 424**: *"the shipped default paints nothing"* → the shipped default
  paints **state grounds** — focus, selection, elevated surface — and still never
  paints the terminal's own background. Keep the old sentence, marked superseded.
- **I26**: *"There is no reverse-video rung"* → superseded. New invariant: at 1-bit a
  selection ground is carried by **reverse video**, and focus keeps its `▸` mark, so
  the two-carrier rule holds with no colour at all.
- Add the ground precedence from `R-STA-002` as a numbered commitment:
  owner or armed › copy selection › focus › hover preview › semantic extent ›
  structural surface; displaced facts keep a mark, edge or weight.

## Code
`src/presentation/theme/` — the resolver that returns an empty `Style` at 1-bit for
surfaces must return reverse video for the **selection** slot only.

## Tests
- `T10.x (I26′, R-SEL-006)`: selection at 1-bit resolves to reverse video.
- `T10.x (R-STA-002)`: focused + selected → selection takes the ground, focus keeps `▸`.
- The six composition cases in C10 (focused+selected+failed, …) as golden frames.

## Accept
Existing depth GIFs (`docs/media/depth-*.gif`) regenerate; the 1-bit one now shows
the selection as reverse video. Say so in the MR.
