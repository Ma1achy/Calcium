# T07 · Verify the landed layout engine

C29 landed at the audited commit. **This is a verification task, not a rebuild.**

Check `src/presentation/layout/` against `reference/LAYOUT_ENGINE.md` and
`reference/11-API-FINALISATION.md`:

- `Grow` has a **weight**; `layout()` accepts an available **height**; paint leaves
  expose a **natural width**; the cache key includes height, representation and
  capability.
- The seven named regressions in `reference/01-ENGINE.md` each have a test.
- **A float moves zero frames.**

Report each as present, absent or different. Build what is absent in this MR.
