# Calcium — nits and ideas

Things noticed in passing that are not yet roadmap entries and are not work. Each carries
enough of its reasoning to be picked up cold, and the ones that turn into rows should move
out of here rather than be duplicated.

---

## 1 · Standard selection behaviour in the prompt

**Extends roadmap #22, which currently rules only `⌃a` and select-all.**

`⌃a` stays line-start — readline, and moving it alone breaks the `⌃a`/`⌃e` pair since `⌃e`
has no GUI conflict. Select-all takes **`⌃⇧a`**, subject to the decoder: `⌃⇧a` and `⌃a` are
frequently **the same byte** (`0x01`), which is the collision that ruled out `⌃_` for undo.
`⌥a` is the fallback.

**Select-all alone is the degenerate case of a selection model**, so the shifted motions
belong with it or the model gets built twice:

```
⇧← ⇧→          extend by character
⌥⇧← ⌥⇧→        extend by word    — pairs with ⌥b/⌥f, which exist
⇧⌃a ⇧⌃e        extend to line start/end — pairs with ⌃a/⌃e, which exist
⌃⇧a            select all
```

**Every one has its motion already bound**, so the keys are not the work. **C17 has no
selection concept at all** — no anchor, no mark, no region. Each shifted motion is *move,
and extend the region from an anchor*; typing replaces the region. That is the model.

**Check every shifted form against the decoder before binding** (T2.13's rule). `⇧←` is
`CSI 1;2D`; `⌥⇧←` is `CSI 1;10D` or an ESC-prefixed form depending on the terminal. **A
binding the decoder cannot produce is the fifteen-unexecuted-bindings class**, and it has
already cost `⌃_`.

**One mechanism, three scopes**: a selection in the editor, a selection in the transcript
(`copyMode`, #15 — a focus target with zero bindings and a producer that returns `false`),
and copy as a verb on a focused thing. Do not build any of the three alone.

---

## 2 · A configurable cursor

Two axes, and only one is trivial.

### The glyph is really the shape, and the terminal draws it

`cursorSequence` is C01's and the **terminal** draws the cursor, so "which character" is
`DECSCUSR`: block, underline or bar, each steady or blinking. **A capability-gated escape,
not something Calcium paints**, and it degrades by being ignored. Cheap.

### The blink default is a state machine, not a terminal setting

**Blinks when idle, steady while typing** is the behaviour worth having and no terminal
offers it: it is *emit the steady variant on a keystroke, emit the blinking variant after
N ms of no input.*

**The refresh driver already owns the clock** — that is the argument that closed the
spinner's "this layer must not grow a timer" premise — so this is a consumer of an existing
mechanism rather than a new timer in `paint.ts`. The constraint survives even though its
premise did not.

### The ruling it needs: per focus target, not global

**The cursor is placed by whatever holds focus** — `Placed.cursor`, relative to the layer's
own origin, absent means hidden (C15 I19). So shape and blink are **per focus target**: a bar
in the prompt and a block in a pushed view is a legitimate thing to want, and **deciding it
as one global setting forecloses it.**

---

## 3 · The nineteen unverified roadmap entries

The status pass marked 8 entries stale and left **19 unchecked, named as unchecked** — *an
OPEN nobody verified reads exactly like one somebody did.*

**So the order below C26 is not yet trustworthy.** Before picking the second feature, re-read
the column: some of the nineteen may already be built, as eight already were.

---

## 4 · MG24 matches published members by name, not identity

Found in stage 2: `ElementReport.kindsCovered` made `ConformanceReport.kindsCovered`'s
exemption look stale.

**The looseness runs the dangerous way.** Not a false positive — **a genuinely unconsumed
member is satisfied the moment any unrelated type anywhere declares a field with that name.**
Any file can create that false negative by accident.

The instance is renamed and the note is in the type. **The rule is still loose**, and it is
the instrument several dispositions have been checked with.

---

## 5 · The pending entry is blank, so a slow tool reads as a hung app

**Most of this exists — the gap is narrower than it looks, and it is worth stating which
part.**

**Already built:** the app route appends a **pending entry immediately** and settles it when
the document arrives, so the transcript gets a row at once. The prompt stays live — C23 I6
releases the guard for a streaming verb precisely so the session is usable during a slow
call. `SPINNER_MS` and its one-shot wake exist. C23 §3b's stall notice fires when a stream
goes quiet past a threshold.

**What is missing: the pending entry has no content.** There is a row and it is blank until
the far side answers. So a five-second tool shows an empty entry under a live prompt, which
reads as *nothing happened* rather than as *waiting*.

### The shape

```
[spinner] /mySlowTool
  ⎿ mySlowTool — running · 4s (cancel: ⌃c)     ← the pending entry, composed at append

── once it settles ────────────────────

❯ /mySlowTool
  [the tool's document]
```

**Three things in that drawing are rulings, not decoration.**

**The spinner replaces the prompt gutter, it does not sit in the entry.** `❯` becomes the
spinner while the verb is in flight and returns when it settles. **That is where a reader
already looks** — the gutter is the one glyph on every submitted line — and it means the
pending entry's content is free to say something more useful than *something is happening*.

It also degrades correctly: `spinnerFrames(caps)` already returns an ASCII set, and the gutter
is one cell at every depth.

**`⎿` rather than `⟩` for the continuation.** The entry is a *branch off* the submitted line,
not a second prompt — and `⟩` is close enough to `❯` to read as one. Needs a glyph slot with
an ASCII pair, per C09 §4: **only the renderer substitutes**, and F122 is the finding for
authoring a mark as a character.

**And the entry names its own escape.** `(cancel: ⌃c)` is the part that turns a wait into a
thing a reader has a choice about — and **it is only honest if the cancel actually reaches
the verb.** C23's ladder rung for an in-flight verb exists; check it before the text promises
it. **A notice offering an escape that does not work is worse than no notice.**

**The pending entry composes a notice at append time**, replaced by the real document at
settlement. `settle(id, doc)` already replaces an entry's whole document, so **the mechanism
is there** — what is absent is anything putting content in before it.

### Three things it needs, and two are already ruled

**The elapsed time is the useful tier, not the spinner** (#26). *Running · 4s* distinguishes
*slow* from *stuck* by a number; a rotating glyph only proves the process is alive. Both need
the same tick, and **the refresh driver owns the clock** — so this is a `b.live` part or a
driver tick, never a `setInterval` in `paint.ts`.

**And "what it is doing" is the tier that turns a wait into information**, where the far side
says so — `docker pull`'s per-layer progress, a tool call's own name. The name is free; the
progress needs a streaming far side.

**The one open question: does the pending notice belong to the framework or the adapter?**
The framework knows the verb and the elapsed time; only the adapter knows what the far side
is doing. A framework default with an adapter override is the likely shape, but it is a
ruling — and a framework that composes a notice the app did not ask for is the same class as
truncating an app's document without being asked (F123).

---

## 6 · Containers with their own scroll — and selection must work across them

**A correction to an earlier ruling of mine, and half of it still stands.**

What I argued against was **mid-row slicing and an independent viewport inside a block**,
because `measure(block, width) → height` is total and pure and every cache, the compositor
and C14's virtualisation rest on it. **That constraint is real** and it is what
`windowPatch` and `BlockDefinition.window` were designed around.

**What was wrong was treating that as "no inner scroll".** A scrollable container is three
things and **all three now exist**:

```
window?      reduces a block to a VALID SMALLER BLOCK of the same kind    F134, built
elements?    navigable positions with a row range                        C26 stage 2, built
a view offset  per container, owned by the focus model                   C26, in progress
```

**Nothing about that breaks the measurement invariant**, because the container measures at
its *declared* height and windows its child — the same move `patch` and `logs` already make.
The expensive thing I refused is not the thing being asked for.

**And it is table stakes.** Claude Code, k9s and lazygit all have panes that scroll
independently. Not having it is a gap, not a position.

### What it needs

**A declared height**, or the container has nothing to scroll *within*. That is `b.row`'s
`height: "fill"` question (#38's neighbourhood) and it is the same ruling: **the block
declares intent, the owner resolves it, and `measure` never sees the unresolved form.**

**And an offset that is view state, not accumulated state** — C23's own rule from the shared
pollers work: *per-part state is view state only; anything that accumulates belongs in a
derivation.* A scroll offset is view state, so it can be dropped and restored freely.

**Scroll position is per container and belongs with focus memory** (C26 I10), which already
has to survive a `putBlock` that removes the focused element. A container whose content is
replaced under a scrolled reader is the same question one level out.

### Selection across a scrolled container — the part that actually needs ruling

**This is the row that does not fall out of the pieces**, and it needs deciding before either
feature is built:

- **Does a selection extend beyond the visible window?** Dragging to the bottom edge of an
  inner container either stops there or auto-scrolls and keeps extending. Both are defensible;
  silently stopping is the one a reader will read as a bug.
- **Does copy take the selected text or the selected elements?** Calcium's advantage is
  **semantic copy** — `y` on a code block copies the code, on a table row copies the row. A
  selection spanning a scrolled container's boundary has to decide whether it is a character
  range or an element range, and those give different answers.
- **And `copyMode` turns mouse tracking off** so the terminal's own selection works — which
  **cannot see an inner container's offset at all.** The terminal selects what is painted;
  the container's hidden rows are not painted. So terminal-native selection and inner scroll
  are in direct tension, and semantic copy is the way out rather than a nicety.

**Build the container and the selection model together, or the second will be retrofitted
against the first.** They are the same concept at two scopes, exactly as the prompt selection,
`copyMode` and semantic copy are.

### The four consumers, and one is nearly built

Naming them together, because a scroll built for one and retrofitted to the others is how the
four end up with four offsets and three of them wrong.

| consumer | state today |
|---|---|
| **the prompt**, when the buffer outgrows `promptRows` | **the window exists and is tail-anchored** |
| the completion menu, when candidates exceed the region | `… N more` and no way to reach them |
| a paste chip's peek | designed, unbuilt |
| a scrollable block in the transcript | the subject of §6 above |

**The prompt is the one to build first, and it is a thread-through rather than a feature.**
`promptWindow` already caps at `frame.promptRows` and draws `⋯` plus the tail, and the code
says why it does not follow the cursor:

> *Around the end rather than around the cursor, until C17's `cursorCell` is threaded
> through: the cursor is at the end for every case but a mid-buffer edit, and showing the
> wrong window is worse than showing the last rows. **Named here so it is a known
> simplification rather than a silent one.***

So *"the prompt should scroll"* is **threading `cursorCell`**, which the file already
identifies as the fix. Edit line three of a fifty-line paste today and the cursor is
off-screen because the window does not ask the editor where it is.

**And it is the same rule as the transcript's scroll anchor** — *the window follows the thing
the reader is attending to* — one in the prompt and one in the transcript. C14's `#anchor`
is the transcript's half and is built.

**The completion menu is the second**, and it is the one that already tells the reader it is
hiding something. `… N more` is C19 rendering the remainder because only C19 knows it —
**so the count exists and the motion does not.** A menu that says *4 more* and cannot reach
them is a stated absence, which is better than a silent one and still a gap.

**One offset concept, four owners.** Each container owns its own offset as view state; the
mechanism that windows and the rule that decides where the window sits are shared. **Build
the rule once** — *the window follows the reader's attention, and says so when it is not
showing everything* — and each consumer is then a small piece of wiring rather than a new
design.

### Two more consumers, and the strongest is the live block

**A live block whose content outgrows its region.** S12's status line reads *1,284 lines
inside a panel showing five* — that is the shape a dashboard has, a `b.live` part that keeps
producing while the reader watches. It is `logs`' whole purpose and it is the case
`BlockDefinition.window` was built for.

**And it is the only consumer where the content moves under the reader**, which is a rule
none of the others need:

```
at the bottom       follow — a tailing log must keep tailing
scrolled up         hold — the reader is reading something
```

That is the scroll-anchor rule inside a container rather than in the transcript, and it is
the one case where *the window follows the reader's attention* has to distinguish **at the
bottom** from **reading**. C14's `#anchor` is the transcript's half and already makes exactly
this distinction — so the rule exists and needs generalising, not inventing.

**A pushed view's inner blocks.** The view has nine flat bindings — `n p g G pageup pagedown
up down escape` — and they scroll **the document**. A `table` of 400 rows inside it has no
inner offset, so `n` moves whole blocks past a table the reader is in the middle of.
**Container scroll and view scroll are two levels and the keys currently mean one.** That is
a C26 question — which level a motion addresses, and how a reader knows — rather than a
container question.

### Where it stops, and the criterion is focus

**"Everything scrolls" is its own defect**, and the line is not *is it a container*:

> **A container scrolls if it is focusable and its content can exceed its declared height.**

**Scroll follows focus** — a keystroke has to land somewhere a reader can see, so a
container with an offset and no focus is a scroll nobody can aim.

**So `b.row`'s children do not scroll independently by default.** A row is layout; an offset
per cell means the reader cannot tell which pane a keystroke reaches without a focus
indicator in every one of them.

**And `panel` and `group` do not scroll as containers.** They group, and their *children*
scroll. A panel with its own offset wrapping a scrollable table is two offsets where a reader
expects one — the four-owners problem inside a single block.

**The criterion admits** the live block, a pushed view's inner blocks, the completion menu,
a paste chip's peek and the prompt. **It excludes** `row`, `panel` and `group`, which have no
declared height of their own and nothing to focus.

---

## 7 · Four seams the modes and containers open together

Each falls out of decisions already taken, and none is answered by them.

### 7a · What does `↓` mean in navigate mode on a scroller?

A scrollable container is focusable, so it holds focus in navigate mode — and `↓` is then
ambiguous: **move to the next element, or scroll the container?**

Every other kind resolves `↓` at an *edge* by `ArrowPolicy`. **A scroller has an edge and an
interior, and the interior is not an element.** So either scrolling requires interact mode —
consistent, and a table you cannot scroll without entering feels stiff — or navigate scrolls
and interact means something else.

**The policy vocabulary was designed before scrollers existed and may have no value for
this.** That is a check before adopting it, not a preference: the third-kind rule (`patch` in
a pushed view) exists for exactly this, and a scroller is a fourth kind that may not fit.

### 7b · Interact mode and the outer scope's scroll keys are the same keys

A pushed view binds `n p g G pageup pagedown`. Enter interact on a table inside it and those
should scroll **the table** — and nothing releases them from the view.

**This is the collision the mode split exists to solve, and it is the first case where the
outer scope's bindings and the inner one's are the same keys** rather than different ones.
`esc` leaves interact and they revert; **check that is the whole story**, because a key
meaning two things in two modes is fine and a key meaning two things in one is not.

### 7c · Is `copyMode` a target, a mode, or both?

`copyMode` sits in `FocusTarget` beside `interaction`. But **copy mode is not a place focus
goes** — it is a modal state where mouse tracking is off and the app draws differently.

Stage 1 ruled `interaction` must be a **target** because a flag consulted before dispatch
gives C16 §5's ladder a rung with an order of its own. **The same argument applies to
`copyMode`** — so it is probably right as a target and probably wrong as a *third mode*
beside navigate and interact. **Settle it before building selection**, or the model carries
two mode concepts.

### 7d · Focus memory says nothing about the mode

C26 I10 restores focus by id with a fall-forward. **It does not say which mode you return
in.** Enter interact on a table, `esc` out, `↓` away, come back — navigate or interact?

Stage 1 made `setMode` preserve the *element*; the converse is unruled. **Probably navigate**
— re-entering a mode you deliberately left is surprising — but it is a ruling and it is cheap
now.

---

## 8 · Scrollbars at container scope, and the mouse

### Not many bars — one, and it follows focus

**A container's scrollbar belongs to the container, drawn inside its own region**, not as a
second bar in the frame's reserved column. That column is the transcript's; a container's is
one cell of its own width, the same trick one scope down.

**Only the focused container draws one.** Three visible scrollers each with a permanent bar
is three cells of chrome for two things nobody is scrolling — and **scroll follows focus** is
already the criterion.

**Which reintroduces the feedback loop the transcript's bar was ruled against**, and the
resolution differs here: a container's width is fixed by its parent and its declared height,
so **reserve the cell always and fill it only when focused.** Width constant, cache safe, no
reflow — the focus gutter's trick, applied to a bar.

### The mouse, and one of the three is new

**Click-to-seek and drag on the bar.** The hit-test already resolves layers by `Placed`, and
`elements` gives row ranges, so a click in the bar's column maps to a fraction of the
content. **Plumbing exists; the affordance does not.**

**Wheel over a container scrolls THAT container, not the transcript** — and this is the new
one. It is 7a's ambiguity for a different device: **the wheel resolves to a container by
POSITION, focus resolves by FOCUS**, because pointing at something is not focusing it. Two
resolution rules for two devices, and they can legitimately disagree about which container a
gesture addresses.

**C02's rule is unchanged**: every mouse affordance has a keyboard equivalent. Drag-to-seek
pairs with `PgUp`/`PgDn`/`g`/`G` **inside** the container — which is 7b's question, so the
two must be answered together.

### And `copyMode` kills the wheel

Wheel events under mouse tracking are reported as button presses, so **turning tracking off
for terminal-native selection kills container scrolling with it.** A reader in copy mode
loses inner scroll entirely.

**Another argument that terminal-native selection and inner scroll are in tension**, and that
**semantic copy is the way out rather than a nicety** — it needs neither tracking off nor a
drag.

---

## 9 · The chrome row has a fifth claimant

`NAV`/`EDIT`, elapsed time, the queued count and the region separators all want the one
chrome row. **A scrollable container adds a fifth thing worth showing** — *where in this
container am I* — which is the scrollbar at container scope rather than transcript scope.

Same mechanism, noted here so it is not designed twice. The chrome decision (#29) now has
five features behind it rather than four.

---

## 10 · Three consequences of a container offset

### 10a · The render cache key is wrong the day a container scrolls

`render-cache.ts` keys on `entry · rev · width · focus · theme name`. **A scroll offset
changes what is rendered and moves none of them** — so scrolling a container serves a stale
render, silently.

**This is `focus`'s exact story one field along**, and `focus` was only in the key because
someone listed what the render reads before trusting the key. The general form is already
recorded: **a cache key is wrong until you have listed everything the render reads.**

**Add the offset when it lands, not after.** A stale render on scroll reads as a drawing
defect, three components from its cause.

### 10b · Resume does not restore scroll — ruled

**A resumed session opens at the bottom of the history log.** Not the transcript offset, not
container offsets, not focus.

**The argument is already in the tree**: view state is droppable — C23's rule from the shared
pollers work, *per-part state is view state only; anything that accumulates belongs in a
derivation.* A scroll offset accumulates nothing, so it is dropped freely and a resumed
session shows the newest thing, which is what a reader opening a session wants.

**Stated here so #34 does not re-decide it**, and so nobody builds persistence for it.

### 10c · At 1-bit the focused container has one affordance left

Everything above assumes a terminal that can show it. Degraded:

```
ASCII      the bar is | and #        already ruled (#36)
1-bit      the wash is gone          so the FILLED BAR CELL is the only focus signal
```

**Four affordances collapse onto one cell**, which is more weight than the reserve-and-fill
rule was carrying at truecolour.

**So the focused container's BORDER changes character** — a different box-drawing weight, or
`+`/`#` at ASCII. It survives every depth, it is one character rather than a colour, and it
is F34's rule applied to a container instead of a verdict: **a distinction must not be
carried by colour alone.**

**Worth having at truecolour too, and optional there** — a reader who wants the border to
mark focus should get it, and one who finds it noisy should be able to turn it off. **Not
optional at 1-bit**, because there is nothing else left.

---

## 11 · `⎿` is a glyph slot, and it has more than one consumer

The pending entry (#5) needs it, and it is not the only place. **A mark that says *this belongs
to the line above* is the same mark everywhere it appears**, so it is a slot in C09's
vocabulary rather than a character each site writes.

**That is F122's finding, and it is one commit old.** Six marks were drawn verbatim by the
framework itself — `❯`, `loading…`, `⠋`, `⋯`, `… n more`, `▸` — under a rule that says a glyph
is a slot and never a character *because only the renderer can substitute.* **Authoring `⎿` at
five sites is that finding again, deliberately.**

### The consumers

```
the pending entry        ⎿ mySlowTool — running · 4s (cancel: ⌃c)
a refusal notice         under the line it refuses
a fault notice           F15's, which appends where the entry should have been
usage on --help          the flags under the verb they belong to
a view's trace line      ⎿ logs opened / ⎿ logs closed · 2m14s
```

**Every one is a continuation of the submitted line**, which is why they want one mark and not
five decisions.

### Degradation

```
unicode: full     ⎿
unicode: ascii    `-` or `|`
```

**`-` reads better than `|`**, because the mark's meaning is *branch* rather than *rule* — `|`
already means a vertical divider in every table this framework draws, and reusing it here is
the two-meanings-one-character class in a glyph.

**Check the substitution is 1:1 by cell count.** C09 I5 wants it, `⎿` is one cell and so is
`-`, so this one is free — unlike `…` → `...`, which was **refused a slot for exactly that
reason** and took the pending glyph instead.

### And SS47 will fire on it

The scan refuses a non-ASCII mark authored in source. **That is the rule working**: `⎿` goes
in the glyph table with its ASCII pair, and every site names the slot. **If a site writes the
character, SS47 says so** — which is the mechanism F122 built and the reason this is a
five-minute change rather than a five-site drift.
