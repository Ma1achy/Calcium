# The comparison catalogue — both arms, side by side

**The unification pass's own assertion is that the arms agree about everything except
resolution. Nothing has looked.**

`svgDecisions` and the disagreement matrix compare *decisions*, and F297 is four instances of
a reader calibrated to an encoding nobody wrote. **A matrix is a claim about what the arms
decide; a frame is what a reader sees.** Both are needed and only one exists.

---

## What to produce

### 1 · Regenerate the terminal catalogue

**It is stale by the whole campaign** — every form at every capability set, and the digest has
moved twice (`64b8845e6408c819` → `d06687b479814a56` → `4c99bab2a88289c7`).

```
890 frames    every form × every variant × five capability sets
              .txt with SGR, .plain stripped, and PNG through catalogue-png.mjs
```

### 2 · Generate the SVG catalogue at parity

**Not the 66 phase frames — the same corpus the terminal renders.** Every form the SVG arm
claims, every variant, at the widths the terminal uses.

**And the refused forms produce a placeholder rather than nothing** — a frame saying
`refused: <reason>`, **so the sheet shows what is missing as clearly as what is present.**
A gap in a contact sheet reads as an oversight; a stated refusal reads as a decision.

### 3 · THE SIDE-BY-SIDE, which is the point

**One image per form·variant·capability, terminal left, SVG right, labelled.**

```
┌──────────────────────────┬──────────────────────────┐
│  bar · grouped · 24bit   │  bar · grouped · svg     │
│                          │                          │
│  [the terminal frame]    │  [the SVG]               │
│                          │                          │
└──────────────────────────┴──────────────────────────┘
```

**Same scale, so the eye compares the figure and not the medium.** The terminal frame is
rendered at its cell size; the SVG is scaled to the same pixel height. **A comparison at
different sizes is a comparison of two pictures rather than two renderings.**

**And at 24-bit only for the pair.** The SVG arm has no ladder, so the other four rungs have
nothing to compare against — **they belong in the terminal sheet and not in the pair.**

### 4 · Two contact sheets

```
the terminal's    every form's default, tiled and labelled — REGENERATED, it is stale
the PAIRED one    every form's default as a side-by-side pair, tiled
```

**The paired sheet is the artefact to review first.** One image, every form, both arms —
**and a form where the two halves read as different products is visible in a second.**

---

## What to look for, and it is not correctness

**The rows already assert correctness. This is for the things no row can reach**, which this
campaign has now demonstrated eleven or twelve times.

```
does the same data read as the same figure     the whole test
weight              is one arm's ink heavier — strokes, fills, densities
proportion          the plot area against the furniture, in both
the gutter          the same fraction, and does it LOOK the same
tick density        the same count is not the same appearance at different resolutions
label size          an SVG label is a font; a terminal label is a cell
the legend          the same entries, and does it sit the same way
colour              the same slot resolving to the same hue — and whether the SVG's
                    antialiasing makes a tone read lighter
empty space         where each arm puts its slack
```

**And the specific things this campaign changed**, which have never been seen together:

```
family 1's mean     a diamond in the series colour, both arms
family 2's tree     topDown in SVG against the terminal's chosen rung
family 6's pie      the arc, the minimum-segment merge in one arm and not the other
the identity gutter a third in the terminal, a tenth in SVG — ruled, and unseen
the frame           four styles, and "grid" drawing gridlines in both
```

---

## How

**Extend the existing tools rather than writing a third.** `plot-catalogue.mjs` renders the
terminal corpus; `phase-catalogue.mjs` renders the SVG's 66. **The pairing is a third pass over
both outputs**, not a third renderer.

```
tools/plot-catalogue.mjs      unchanged, regenerated
tools/svg-catalogue.mjs       phase-catalogue widened to the full corpus
tools/pair-catalogue.mjs      NEW — reads both, emits the pairs and the paired sheet
```

**Order matters and it has bitten before**: `plot-catalogue.mjs` **clears its directory**, so
anything writing into the same tree runs after it (F261).

**And the digests stay split** (F264) — terminal, SVG, and now paired, **because an addition to
one read as a change to both.**

---

## The gate

**This produces no source change, so the gates are a guard against collateral rather than the
point.**

**But two counters matter:**

```
how many pairs were produced        against how many the corpus should yield —
                                    a missing pair is a form that rendered in one arm
                                    and not the other, which is the sheet's whole job
how many refusals were drawn        against SVG_FAMILY's null count. They must agree,
                                    or a form is refused somewhere the record does not say
```

**F264's lesson applies to the pairing too**: a hash over both arms cannot tell an addition
from a change.

---

## And it goes before the remaining forms

**Not after.** The residue and family 8 add twelve to fifteen forms, **and every one is a pair
nobody has looked at.**

**Reviewing the sheet now sets what the remaining forms are built to match** — and the
campaign's own record says the arms drift where nobody looks: **sixteen disagreements were
found by a sweep that ran once, and eleven or twelve defects have been found by reading frames
rather than by any row.**
